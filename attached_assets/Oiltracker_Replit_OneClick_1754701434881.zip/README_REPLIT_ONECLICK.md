
# Oiltracker — Replit One‑Click (API + Front)
Aucun terminal nécessaire.

## Étapes
1) Aller sur https://replit.com → **Create Repl** → **Python**.
2) Uploader **tout le zip** et l’extraire dans le Repl (ou uploade les fichiers un par un).
3) Clique sur **Run** (le script installe les libs puis lance le serveur).
4) Clique **Open in new tab** → l’interface est servie sur `/static/`.
5) Connecte‑toi : **y.sayadi@direct-medical.net / admin123**.

Endpoints utiles (si besoin) :
- `POST /auth/login` (JSON body)
- `GET /market`
- `GET /chat`, `POST /chat`
